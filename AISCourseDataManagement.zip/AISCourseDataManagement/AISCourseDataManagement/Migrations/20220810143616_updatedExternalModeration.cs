﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AISCourseDataManagement.Migrations
{
    public partial class updatedExternalModeration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsSentEmail",
                table: "externalModeration",
                type: "bit",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsSentEmail",
                table: "externalModeration");
        }
    }
}
