﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AISCourseDataManagement.Migrations
{
    public partial class ExternalModerationUpdated : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_externalModeration",
                table: "externalModeration");

            migrationBuilder.RenameColumn(
                name: "CourseID",
                table: "externalModeration",
                newName: "CourseId");

            migrationBuilder.AlterColumn<int>(
                name: "CourseId",
                table: "externalModeration",
                type: "int",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.AddColumn<int>(
                name: "Id",
                table: "externalModeration",
                type: "int",
                nullable: false,
                defaultValue: 0)
                .Annotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AddColumn<string>(
                name: "FileName",
                table: "externalModeration",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "FilePath",
                table: "externalModeration",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Version",
                table: "courseDescriptor",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "Programme",
                table: "courseDescriptor",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "CourseTitle",
                table: "courseDescriptor",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "CourseCode",
                table: "courseDescriptor",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddPrimaryKey(
                name: "PK_externalModeration",
                table: "externalModeration",
                column: "Id");

            migrationBuilder.CreateIndex(
                name: "IX_externalModeration_CourseId",
                table: "externalModeration",
                column: "CourseId");

            migrationBuilder.AddForeignKey(
                name: "FK_externalModeration_Course_CourseId",
                table: "externalModeration",
                column: "CourseId",
                principalTable: "Course",
                principalColumn: "CourseID",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_externalModeration_Course_CourseId",
                table: "externalModeration");

            migrationBuilder.DropPrimaryKey(
                name: "PK_externalModeration",
                table: "externalModeration");

            migrationBuilder.DropIndex(
                name: "IX_externalModeration_CourseId",
                table: "externalModeration");

            migrationBuilder.DropColumn(
                name: "Id",
                table: "externalModeration");

            migrationBuilder.DropColumn(
                name: "FileName",
                table: "externalModeration");

            migrationBuilder.DropColumn(
                name: "FilePath",
                table: "externalModeration");

            migrationBuilder.RenameColumn(
                name: "CourseId",
                table: "externalModeration",
                newName: "CourseID");

            migrationBuilder.AlterColumn<string>(
                name: "CourseID",
                table: "externalModeration",
                type: "nvarchar(450)",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AlterColumn<string>(
                name: "Version",
                table: "courseDescriptor",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Programme",
                table: "courseDescriptor",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CourseTitle",
                table: "courseDescriptor",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CourseCode",
                table: "courseDescriptor",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AddPrimaryKey(
                name: "PK_externalModeration",
                table: "externalModeration",
                column: "CourseID");
        }
    }
}
