﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AISCourseDataManagement.Data;
using AISCourseDataManagement.Models;
using Microsoft.AspNetCore.Authorization;

namespace AISCourseDataManagement.Controllers
{
    public class CourseVersionController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CourseVersionController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: CourseVersion
        [Authorize]
        public async Task<IActionResult> Index()
        {
            return View(await _context.CourseVersion.Include("Course").ToListAsync());
        }

        // GET: CourseVersion/Details/5
        [Authorize]
        public async Task<IActionResult> Details(int id)
        {
            if (id == 0)
            {
                return NotFound();
            }
            var course = await _context.CourseVersion
                .FirstOrDefaultAsync(m => m.VersionID == id);
            if (course == null)
            {
                return NotFound();
            }
            return View(course);
        }

        // GET: CourseVersion/Create
        [Authorize]
        public IActionResult Create()
        {
            ViewBag.CourseId = new SelectList(_context.Course, "CourseID", "CourseCode");
            return View();
        }

        // POST: CourseVersion/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CourseId,Version,VersionDescription")] CourseVersion courseVersion)
        {

            if (ModelState.IsValid)
            {
                _context.Add(courseVersion);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            return View(courseVersion);
        }

        // GET: CourseVersion/Edit/5
        [Authorize]
        public async Task<IActionResult> Edit(int id)
        {
            if (id == 0)
            {
                return NotFound();
            }

            var courseVersion = await _context.CourseVersion.FindAsync(id);
            if (courseVersion == null)
            {
                return NotFound();
            }
            ViewBag.CourseId = new SelectList(_context.Course, "CourseID", "CourseCode", courseVersion.CourseId);
            return View(courseVersion);
        }

        // POST: CourseVersion/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("VersionID,CourseId,Version,VersionDescription")] CourseVersion courseVersion)
        {
            if (id != courseVersion.VersionID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(courseVersion);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CourseVersionExists(courseVersion.VersionID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(courseVersion);
        }

        // GET: CourseVersion/Delete/5
        [Authorize]
        public async Task<IActionResult> Delete(int id)
        {
            if (id == 0)
            {
                return NotFound();
            }

            var courseVersion= await _context.CourseVersion
                .FirstOrDefaultAsync(m => m.VersionID == id);
            if (courseVersion == null)
            {
                return NotFound();
            }

            return View(courseVersion);
        }

        // POST: CourseVersion/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var courseVersion = await _context.CourseVersion.FindAsync(id);
            _context.CourseVersion.Remove(courseVersion);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CourseVersionExists(int id)
        {
            return _context.CourseVersion.Any(e => e.VersionID == id);
        }
    }
    
}
