﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AISCourseDataManagement.Data;
using AISCourseDataManagement.Models;
using Microsoft.AspNetCore.Authorization;
using Syncfusion.DocIO;
using Syncfusion.DocIO.DLS;
using System.IO;
using AngleSharp.Text;
using Microsoft.AspNetCore.Http;
using System.Net.Mail;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;

namespace AISCourseDataManagement.Controllers
{
    public class ExternalModerationsController : Controller
    {
        private readonly ApplicationDbContext _context;
        public ExternalModerationsController(ApplicationDbContext context)
        {
            _context = context;
        }
        // GET: ExternalModerations
        [Authorize]
        public async Task<IActionResult> Index()
        {
            ViewBag.CourseId = new SelectList(_context.Course, "CourseID", "CourseCode");
            var list = await _context.externalModeration.Include("Course").ToListAsync();
            return View(list);
        }

        // GET: ExternalModerations/Details/5
        [Authorize]
        public async Task<IActionResult> Details(int id)
        {
            if (id == 0)
            {
                return NotFound();
            }
            var externalModeration = await _context.externalModeration
                .FirstOrDefaultAsync(m => m.Id == id);
            if (externalModeration == null)
            {
                return NotFound();
            }
            return View(externalModeration);
        }

        // GET: ExternalModerations/Create
        [Authorize]
        public IActionResult Create()
        {
            ViewBag.CourseId = new SelectList(_context.Course, "CourseID", "CourseCode");
            return View();
        }

        // POST: ExternalModerations/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CourseId,NameOfExternalModerator,DatePassedToExternalModerator,DateOfExternalmoderatorReport,DateOfResponseToReport,NextDueDateForExternalModeration,SendEmailNotificationTo")] ExternalModeration externalModeration,IFormFile file)
        {
            //if (ModelState.IsValid)
            //{
                _context.Add(externalModeration);
                await _context.SaveChangesAsync();
                await UploadFile(externalModeration.Id,file);
                return RedirectToAction(nameof(Index));
            //}
            //return View(externalModeration);
        }

        // Upload file on server
        public async Task<bool> UploadFile(int id,IFormFile file)
        {
            string path = "";
            bool iscopied = false;
            try
            {
                if (file.Length > 0)
                {
                    string filename = Guid.NewGuid() + Path.GetExtension(file.FileName);
                    path = Path.GetFullPath(Path.Combine(Directory.GetCurrentDirectory(), "Upload"));
                    using (var filestream = new FileStream(Path.Combine(path, filename), FileMode.Create))
                    {
                        await file.CopyToAsync(filestream);
                    }
                    iscopied = true;
                    var externalModeration = await _context.externalModeration.FindAsync(id);
                    if (externalModeration == null)
                    {
                        iscopied = false;
                    }
                    externalModeration.FilePath = path;
                    externalModeration.FileName = filename;
                    _context.Update(externalModeration);
                    await _context.SaveChangesAsync();
                }
                else
                {
                    iscopied = false;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return iscopied;
        }
        public ActionResult DownloadFile(string filePath,string fileName)
        {
            string fullName = filePath+"\\"+fileName;
            byte[] fileBytes = GetFile(fullName);
            if (fileName.Contains(".jpg") || fileName.Contains(".png"))
            {
                return File(
                    fileBytes, System.Net.Mime.MediaTypeNames.Image.Jpeg, fileName);
            }
            else if (fileName.Contains(".doc") || fileName.Contains(".docx"))
            {
                return File(
                    fileBytes, System.Net.Mime.MediaTypeNames.Application.Rtf, fileName);
            }
            else
            {
                return File(
                    fileBytes, System.Net.Mime.MediaTypeNames.Application.Pdf,fileName);
            }
        }

        byte[] GetFile(string s)
        {
            System.IO.FileStream fs = System.IO.File.OpenRead(s);
            byte[] data = new byte[fs.Length];
            int br = fs.Read(data, 0, data.Length);
            if (br != fs.Length)
                throw new System.IO.IOException(s);
            return data;
        }

        [HttpGet]
        //[ValidateAntiForgeryToken]
        public async Task<ActionResult> SentEmail(int Id)
        {
            //if (ModelState.IsValid)
            //{   
                //Send Email
                MailMessage Msg = new MailMessage();
                var externalModeration = await _context.externalModeration.FindAsync(Id);
                Msg.From = new MailAddress(""); // replace with valid value
                Msg.Subject = "This is Simple Email Check";
                Msg.To.Add(externalModeration.SendEmailNotificationTo); //replace with correct values

            if (externalModeration != null)
            {
                string fullName = externalModeration.FilePath + "\\" + externalModeration.FileName;
                Msg.Attachments.Add(new Attachment(fullName));
            };

            Msg.Body = "This is Automatically Generated Email";
                Msg.IsBodyHtml = true;
                Msg.Priority = MailPriority.High;
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.Port = 587;
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new NetworkCredential("", "");// replace with valid value
                smtp.EnableSsl = true;
                smtp.Timeout = 20000;
                ServicePointManager.ServerCertificateValidationCallback =
                delegate (object s, System.Security.Cryptography.X509Certificates.X509Certificate certificate, X509Chain chain,
                SslPolicyErrors sslPolicyErrors)
                { return true; };
                smtp.Send(Msg);

                return RedirectToAction("Sent");
            //}
            //return View();
        }

       
        public ActionResult Sent()
        {
            return View();
        }

        // GET: ExternalModerations/Edit/5
        [Authorize]
        public async Task<IActionResult> Edit(int id, string CourseName, string NameOfExternalModerator, DateTime DatePassedToExternalModerator, DateTime DateOfExternalModeratorReport, DateTime DateOfResponseToReport, DateTime NextDueDateForExternalModeration, string SendEmailNotificationTo)
        {
            if (id == 0)
            {
                return NotFound();
            }
            var externalModeration = await _context.externalModeration.FindAsync(id);
            if (externalModeration == null)
            {
                return NotFound();
            }
            ViewBag.CourseId = new SelectList(_context.Course, "CourseID", "CourseCode");
            return View(externalModeration);   
        }

        public async Task<IActionResult> Action1()
        {
            return View();
        }

        public async Task<IActionResult> CreateDocument(int id, string CourseName, string NameOfExternalModerator, DateTime DatePassedToExternalModerator, DateTime DateOfExternalModeratorReport, DateTime DateOfResponseToReport, DateTime NextDueDateForExternalModeration, string SendEmailNotificationTo)
        {
            string s1 = CourseName;
            string s2 = NameOfExternalModerator;
            DateTime d1 = DatePassedToExternalModerator;
            DateTime d2 = DateOfExternalModeratorReport;
            DateTime d3 = DateOfResponseToReport;
            DateTime d4 = NextDueDateForExternalModeration;
            string s3 = SendEmailNotificationTo;

            // Creating a new document.
            WordDocument document = new WordDocument();
            //Adding a new section to the document.
            WSection section = document.AddSection() as WSection;
            //Set Margin of the section
            section.PageSetup.Margins.All = 72;
            //Set page size of the section
            section.PageSetup.PageSize = new Syncfusion.Drawing.SizeF(612, 792);
            //Create Paragraph styles
            WParagraphStyle style = document.AddParagraphStyle("Normal") as WParagraphStyle;
            style.CharacterFormat.FontName = "Calibri";
            style.CharacterFormat.FontSize = 11f;
            style.ParagraphFormat.BeforeSpacing = 0;
            style.ParagraphFormat.AfterSpacing = 8;
            style.ParagraphFormat.LineSpacing = 13.8f;

            style = document.AddParagraphStyle("Heading 1") as WParagraphStyle;
            style.ApplyBaseStyle("Normal");
            style.CharacterFormat.FontName = "Calibri Light";
            style.CharacterFormat.FontSize = 16f;
            style.CharacterFormat.TextColor = Syncfusion.Drawing.Color.FromArgb(46, 116, 181);
            style.ParagraphFormat.BeforeSpacing = 12;
            style.ParagraphFormat.AfterSpacing = 0;
            style.ParagraphFormat.Keep = true;
            style.ParagraphFormat.KeepFollow = true;
            style.ParagraphFormat.OutlineLevel = OutlineLevel.Level1;
            IWParagraph paragraph = section.HeadersFooters.Header.AddParagraph();

            paragraph.ApplyStyle("Normal");
            paragraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Left;
            WTextRange textRange = paragraph.AppendText("Sample") as WTextRange;
            textRange.CharacterFormat.FontSize = 12f;
            textRange.CharacterFormat.FontName = "Calibri";
            textRange.CharacterFormat.TextColor = Syncfusion.Drawing.Color.Red;

            //Appends paragraph.
            paragraph = section.AddParagraph();
            paragraph.ApplyStyle("Heading 1");
            paragraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Center;
            textRange = paragraph.AppendText(""+CourseName) as WTextRange;
            paragraph = section.AddParagraph();
            paragraph.ApplyStyle("Heading 1");
            paragraph.ParagraphFormat.HorizontalAlignment = HorizontalAlignment.Left;

            //Appends paragraph.
            section.AddParagraph();

            //Saves the Word document to  MemoryStream
            MemoryStream stream = new MemoryStream();
            document.Save(stream, FormatType.Docx);
            stream.Position = 0;

            //Download Word document in the browser
            return File(stream, "application/msword", "Sample.docx");

        }

        // POST: ExternalModerations/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,CourseId,NameOfExternalModerator,DatePassedToExternalModerator,DateOfExternalmoderatorReport,DateOfResponseToReport,NextDueDateForExternalModeration,SendEmailNotificationTo")] ExternalModeration externalModeration,IFormFile file)
        {
            if (id != externalModeration.Id && file.FileName!=null)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(externalModeration);
                    await _context.SaveChangesAsync();
                    await UploadFile(externalModeration.Id,file);
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ExternalModerationExists(externalModeration.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }

            return View(externalModeration);
        }

        // GET: ExternalModerations/Delete/5
        [Authorize]
        public async Task<IActionResult> Delete(int id)
        {
            if (id == 0)
            {
                return NotFound();
            }
            var externalModeration = await _context.externalModeration
                .FirstOrDefaultAsync(m => m.Id == id);
            if (externalModeration == null)
            {
                return NotFound();
            }
            return View(externalModeration);
        }

        // POST: ExternalModerations/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var externalModeration = await _context.externalModeration.FindAsync(id);
            _context.externalModeration.Remove(externalModeration);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ExternalModerationExists(int id)
        {
            return _context.externalModeration.Any(e => e.Id == id);
        }
    }
}
