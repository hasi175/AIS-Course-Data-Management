﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AISCourseDataManagement.Data;
using AISCourseDataManagement.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
//using Syncfusion.DocIO.DLS;
using System.IO;
using Syncfusion.DocIO;
//using NPOI.XWPF;
//using NPOI.XWPF.UserModel;
using System.Net.Mail;
using System.Net;
using System.Net.Security;
using Syncfusion.DocIO.DLS;

namespace AISCourseDataManagement.Controllers
{
    public class CourseDescriptorsController : Controller
    {
        private readonly ApplicationDbContext _context;
        public CourseDescriptorsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: CourseDescriptors
        [Authorize]
        public async Task<IActionResult> Index()
        {
            return View(await _context.courseDescriptor.Include("Course").Include("CourseVersion").ToListAsync());
        }

        // GET: CourseDescriptors/Details/5
        //[Authorize]
        public async Task<IActionResult> Details(int id)
        {
            if (id == 0)
            {
                return NotFound();
            }
            var courseDescriptor = await _context.courseDescriptor
                .FirstOrDefaultAsync(m => m.CourseDescriptorID == id);
            if (courseDescriptor == null)
            {
                return NotFound();
            }
            return View(courseDescriptor);
        }

        // GET: CourseDescriptors/Create
        [Authorize]
        public IActionResult Create()
        {
            ViewBag.CourseId = new SelectList(_context.Course, "CourseID", "CourseCode");
            ViewBag.CourseVersionId = new SelectList(_context.CourseVersion, "VersionID", "Version");
            return View();
        }

        // POST: CourseDescriptors/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CourseDescriptorID,Programme,CourseId,CourseVersionId,NZQFLevel,Credits,Prerequisites,Corequisites,Restrictions,CourseAim,DeliveryMethods,DateLastUpdated,LearningOutcomes,TeachingHours,SelfDirectedHours,TotalHours,TotalWeeks,Assessment1,Assessment1Weight,Assessment1LearningOutcomes,Assessment2,Assessment2Weight,Assessment2LearningOutcomes,Assessment3,Assessment3Weight,Assessment3LearningOutcomes,Assessment4,Assessment4Weight,Assessment4LearningOutcomes,Assessment5,Assessment5Weight,Assessment5LearningOutcomes,Content")] CourseDescriptor courseDescriptor)
        {
            //if (ModelState.IsValid)
            //{
                if (courseDescriptor.CourseDescriptorID == 0)
                {
                    _context.Add(courseDescriptor);
                }
                else
                {
                    _context.Update(courseDescriptor);
                }
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
           // }
            //return View(courseDescriptor);
        }


        // GET: CourseDescriptors/ViewTemplate
        [HttpGet]
        public async Task<IActionResult> ViewTemplate(int id)
        {
            if (id == 0)
            {
                return NotFound();
            }
            var courseDescriptor = await _context.courseDescriptor.Include("Course").Include("CourseVersion").FirstOrDefaultAsync(m => m.CourseDescriptorID == id);
            
            //Creates new Word document instance for word processing.
            using (WordDocument document = new WordDocument())
            {

                //Opens the input Word document.
                //FileStream docStream = File.OpenRead(Path.GetFullPath(@"../../../Template.docx"));
                string fullPath = Path.GetFullPath(@"CourseOutlineTemplate.docx");
                FileStream docStream = System.IO.File.OpenRead(fullPath);
                document.Open(docStream, FormatType.Docx);
                docStream.Dispose();
                //Finds all occurrences of a misspelled word and replaces with properly spelled word.

                document.Replace("+COURSE TITLE+", (string.IsNullOrEmpty(courseDescriptor.Course.CourseTitle) ? "" : courseDescriptor.Course.CourseTitle), true, true);
                document.Replace("+COURSE CODE +", (string.IsNullOrEmpty(courseDescriptor.Course.CourseCode) ? "" : courseDescriptor.Course.CourseCode), true, true);
                document.Replace("+COURSE CODE+", (string.IsNullOrEmpty(courseDescriptor.Course.CourseCode) ? "" : courseDescriptor.Course.CourseCode), true, true);
                document.Replace("+COURSE TITLE+", (string.IsNullOrEmpty(courseDescriptor.Course.CourseTitle) ? "" : courseDescriptor.Course.CourseTitle), true, true);
                document.Replace("+PREREQUISITES:+",(string.IsNullOrEmpty(courseDescriptor.Prerequisites) ? "" : courseDescriptor.Prerequisites), true, true);
                document.Replace("+course code+", (string.IsNullOrEmpty(courseDescriptor.Prerequisites)?"":(string.IsNullOrEmpty(courseDescriptor.Course.CourseCode) ? "" : courseDescriptor.Course.CourseCode)), true, true);
                document.Replace("+title of the course+", (string.IsNullOrEmpty(courseDescriptor.Prerequisites) ? "" : (string.IsNullOrEmpty(courseDescriptor.Course.CourseTitle) ? "" : courseDescriptor.Course.CourseTitle)), true, true);
                document.Replace("+CO-REQUISITES:+", (string.IsNullOrEmpty(courseDescriptor.Corequisites) ? "" : courseDescriptor.Corequisites), true, true);
                document.Replace("+course code +", (string.IsNullOrEmpty(courseDescriptor.Corequisites) ? "" : (string.IsNullOrEmpty(courseDescriptor.Course.CourseCode) ? "" : courseDescriptor.Course.CourseCode)), true, true);
                document.Replace("+title of the course +", (string.IsNullOrEmpty(courseDescriptor.Corequisites) ? "" : (string.IsNullOrEmpty(courseDescriptor.Course.CourseTitle) ? "" : courseDescriptor.Course.CourseTitle)), true, true);
                document.Replace("+CO-REQUISITES:+", (string.IsNullOrEmpty(courseDescriptor.Restrictions) ? "" : courseDescriptor.Restrictions), true, true);
                document.Replace("+course code  +", (string.IsNullOrEmpty(courseDescriptor.Restrictions) ? "" : (string.IsNullOrEmpty(courseDescriptor.Course.CourseCode) ? "" : courseDescriptor.Course.CourseCode)), true, true);
                document.Replace("+title of the course  +", (string.IsNullOrEmpty(courseDescriptor.Restrictions) ? "" : (string.IsNullOrEmpty(courseDescriptor.Course.CourseTitle) ? "" : courseDescriptor.Course.CourseTitle)), true, true);
                document.Replace("+ASSESSMENT 1+", (string.IsNullOrEmpty(courseDescriptor.Assessment1) ? "" : courseDescriptor.Assessment1), true, true);
                document.Replace("+ASSESSMENT 2+", (string.IsNullOrEmpty(courseDescriptor.Assessment2) ? "" : courseDescriptor.Assessment2), true, true);
                document.Replace("+ASSESSMENT 3+", (string.IsNullOrEmpty(courseDescriptor.Assessment3) ? "" : courseDescriptor.Assessment3), true, true);
                document.Replace("+Copy from the course descriptor1+", (string.IsNullOrEmpty(courseDescriptor.Assessment1LearningOutcomes) ? "" : courseDescriptor.Assessment1LearningOutcomes), true, true);
                document.Replace("+Copy from the course descriptor2+", (string.IsNullOrEmpty(courseDescriptor.Assessment2LearningOutcomes) ? "" : courseDescriptor.Assessment2LearningOutcomes), true, true);
                document.Replace("+Copy from the course descriptor3+", (string.IsNullOrEmpty(courseDescriptor.Assessment3LearningOutcomes) ? "" : courseDescriptor.Assessment3LearningOutcomes), true, true);
                document.Replace("+Copy from the course descriptor4+", (string.IsNullOrEmpty(courseDescriptor.Assessment4LearningOutcomes) ? "" : courseDescriptor.Assessment4LearningOutcomes), true, true);
                document.Replace("+Copy from the course descriptor5+", (string.IsNullOrEmpty(courseDescriptor.Assessment5LearningOutcomes) ? "" : courseDescriptor.Assessment5LearningOutcomes), true, true);
                document.Replace("++COPY THE CONTENT/ TOPICS FROM THE COURSE DESCRIPTOR++", (string.IsNullOrEmpty(courseDescriptor.Content) ? "" : courseDescriptor.Content), true, true);
                document.Replace("+Copy from the course descriptor aim+", (string.IsNullOrEmpty(courseDescriptor.CourseAim) ? "" : courseDescriptor.CourseAim), true, true);
                
                 //Saves the resultant file in the given path.
                 docStream = System.IO.File.Create(Path.GetFullPath(@"Result"+id+".docx"));
                 //docStream = System.IO.File.Create(Path.GetFullPath(@"Result.docx"));
                 document.Save(docStream,FormatType.Docx);

                docStream.Dispose();
                document.Dispose();

                //string wordHTML = System.IO.File.ReadAllText(Path.GetFullPath(@"Result.docx"));
                string wordHTML = Path.GetFullPath(@"Result" +id +".docx");
                //System.IO.File.Delete(Path.GetFullPath(@"Result.docx"));
                ViewBag.WordHtml = wordHTML;
            }
            return View();
        }

        [HttpGet]
        public JsonResult LoadCourseVersionByCourse(string courseId)
        {
            //Your Code For Getting Physicans Goes Here
            var courseList = new SelectList(_context.CourseVersion.Where(c=>c.CourseId== Convert.ToInt32(courseId)), "VersionID", "Version");
            return Json(courseList);
        }

        [HttpGet]
        public JsonResult LoadCourseDescriptionByCourseAndVersionId(string courseId,string versionId)
        {
            //Your Code For Getting Physicans Goes Here
            var courseDescription = _context.courseDescriptor.Where(c => c.CourseId == Convert.ToInt32(courseId) && c.CourseVersionId == Convert.ToInt32(versionId)).FirstOrDefault();
            return Json(courseDescription);
        }

        // GET: CourseDescriptors/Edit/5
        [Authorize]
        public async Task<IActionResult> Edit(int id)
        {
            if (id == 0)
            {
                return NotFound();
            }
            var courseDescriptor = await _context.courseDescriptor.FindAsync(id);
            ViewBag.CourseId = new SelectList(_context.Course, "CourseID", "CourseCode", courseDescriptor.CourseId);
            ViewBag.CourseVersionId = new SelectList(_context.CourseVersion, "VersionID", "Version", courseDescriptor.CourseVersionId);
            if (courseDescriptor == null)
            {
                return NotFound();
            }
            return View(courseDescriptor);
        }

        // POST: CourseDescriptors/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CourseDescriptorID,Programme,CourseId,CourseCode,CourseVersionId,Version,CourseTitle,NZQFLevel,Credits,Prerequisites,Corequisites,Restrictions,CourseAim,DeliveryMethods,DateLastUpdated,LearningOutcomes,TeachingHours,SelfDirectedHours,TotalHours,TotalWeeks,Assessment1,Assessment1Weight,Assessment1LearningOutcomes,Assessment2,Assessment2Weight,Assessment2LearningOutcomes,Assessment3,Assessment3Weight,Assessment3LearningOutcomes,Assessment4,Assessment4Weight,Assessment4LearningOutcomes,Assessment5,Assessment5Weight,Assessment5LearningOutcomes,Content")] CourseDescriptor courseDescriptor)
        {
            if (id != courseDescriptor.CourseDescriptorID)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(courseDescriptor);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CourseDescriptorExists(courseDescriptor.CourseDescriptorID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(courseDescriptor);
        }

        // GET: CourseDescriptors/Delete/5
        [Authorize]
        public async Task<IActionResult> Delete(int id)
        {
            if (id == 0)
            {
                return NotFound();
            }

            var courseDescriptor = await _context.courseDescriptor.FirstOrDefaultAsync(m => m.CourseDescriptorID == id);
            if (courseDescriptor == null)
            {
                return NotFound();
            }
            return View(courseDescriptor);
        }

        // POST: CourseDescriptors/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var courseDescriptor = await _context.courseDescriptor.FindAsync(id);
            _context.courseDescriptor.Remove(courseDescriptor);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CourseDescriptorExists(int id)
        {
            return _context.courseDescriptor.Any(e => e.CourseDescriptorID == id);
        }
    }
}
