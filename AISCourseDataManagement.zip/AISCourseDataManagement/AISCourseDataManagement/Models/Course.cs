﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AISCourseDataManagement.Models
{
    public class Course
    {
        [Key]
        public int CourseID { get; set; }

        [Display(Name = "Course Code")]
        [Required(ErrorMessage = "Course code must be entered")]
        public string CourseCode { get; set; }

        [Display(Name = "Course Title")]
        [Required(ErrorMessage = "Course Title must be entered")]
        public string CourseTitle { get; set; }

        [Display(Name = "Course Description")]
        [Required(ErrorMessage = "Course Description must be entered")]
        public string CourseDescription { get; set; }

    }
}
