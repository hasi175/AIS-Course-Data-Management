﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AISCourseDataManagement.Models
{
    public class CourseDescriptor
    {
        [Key]
        [Display(Name = "Course Descriptor ID")]
        public int CourseDescriptorID { get; set; }

        [Display(Name = "Programme")]
        //[Required(ErrorMessage = "Programme must be entered")]
        public string Programme { get; set; }

        public int? CourseId { get; set; }
        public Course Course { get; set; }

        public int? CourseVersionId { get; set; }
        public CourseVersion CourseVersion { get; set; }

        [Display(Name = "Course Code")]
        //[Required(ErrorMessage = "Course code must be entered")]
        public string CourseCode { get; set; }

        [Display(Name = "Version")]
        //[Required(ErrorMessage = "Version must be entered")]
        public string Version { get; set; }

        [Display(Name = "Course Title")]
        //[Required(ErrorMessage = "Course Title must be entered")]
        public string CourseTitle { get; set; }

        [Display(Name = "NZQF Level")]
        [Required(ErrorMessage = "NZQF Level must be entered")]
        public string NZQFLevel { get; set; }

        [Display(Name = "Credits")]
        [Required(ErrorMessage = "Credits must be entered")]
        public int Credits { get; set; }

        [Display(Name = "Prerequisites")]
        [Required(ErrorMessage = "Prerequisites must be entered")]
        public string Prerequisites { get; set; }

        [Display(Name = "Co-requisites")]
        [Required(ErrorMessage = "Co-requisites must be entered")]
        public string Corequisites { get; set; }

        [Display(Name = "Restrictions")]
        [Required(ErrorMessage = "Restrictions must be entered")]
        public string Restrictions { get; set; }

        [Display(Name = "Course Aim")]
        [Required(ErrorMessage = "Course Aim must be entered")]
        public string CourseAim { get; set; }

        [Display(Name = "Delivery Methods")]
        [Required(ErrorMessage = "Delivery Methods must be entered")]
        public string DeliveryMethods { get; set; }

        [Display(Name = "Date Last Updated")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        [Required(ErrorMessage = "Date last updated must be entered")]
        public DateTime DateLastUpdated { get; set; }


        [Display(Name = "Learning Outcomes")]
        [Required(ErrorMessage = "Learning Outcomes must be entered")]
        public string LearningOutcomes { get; set; }


        [Display(Name = "Teaching Hours")]
        [Required(ErrorMessage = "Teaching Hours must be entered")]
        public int TeachingHours { get; set; }

        [Display(Name = "Self-directed Hours")]
        [Required(ErrorMessage = "Self-Directed Hours must be entered")]
        public int SelfDirectedHours { get; set; }

        [Display(Name = "Total Hours")]
        [Required(ErrorMessage = "Total Hours must be entered")]
        public int TotalHours { get; set; }

        [Display(Name = "Total Weeks")]
        [Required(ErrorMessage = "Total Weeks must be entered")]
        public int TotalWeeks { get; set; }

        [Display(Name = "Assessment 1")]
        public string Assessment1 { get; set; }

        [Display(Name = "Assessment 1 Weight (%)")]
        public string Assessment1Weight { get; set; }

        [Display(Name = "Assessment 1 Learning Outcomes")]
        public string Assessment1LearningOutcomes { get; set; }

        [Display(Name = "Assessment 2")]
        public string Assessment2 { get; set; }

        [Display(Name = "Assessment 2 Weight (%)")]
        public string Assessment2Weight { get; set; }

        [Display(Name = "Assessment 2 Learning Outcomes")]
        public string Assessment2LearningOutcomes { get; set; }

        [Display(Name = "Assessment 3")]
        public string Assessment3 { get; set; }

        [Display(Name = "Assessment 3 Weight (%)")]
        public string Assessment3Weight { get; set; }

        [Display(Name = "Assessment 3 Learning Outcomes")]
        public string Assessment3LearningOutcomes { get; set; }

        [Display(Name = "Assessment 4")]
        public string Assessment4 { get; set; }

        [Display(Name = "Assessment 4 Weight (%)")]
        public string Assessment4Weight { get; set; }

        [Display(Name = "Assessment 4 Learning Outcomes")]
        public string Assessment4LearningOutcomes { get; set; }

        [Display(Name = "Assessment 5")]
        public string Assessment5 { get; set; }

        [Display(Name = "Assessment 5 Weight (%)")]
        public string Assessment5Weight { get; set; }

        [Display(Name = "Assessment 5 Learning Outcomes")]
        public string Assessment5LearningOutcomes { get; set; }

        [Display(Name = "Content")]
        [Required(ErrorMessage = "Content must be entered")]
        public string Content { get; set; }
    }
}
