﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;


namespace AISCourseDataManagement.Models
{
    public class ExternalModeration
    {
        [Key]
        [Display(Name = "Id")]
        [Required(ErrorMessage = "Id must be entered")]
        public int Id { get; set; }

        [Display(Name = "Course ID")]
        [Required(ErrorMessage = "Course ID must be entered")]
        public int? CourseId { get; set; }
        public Course Course { get; set; }

        [Display(Name = "Course Name")]
        public string CourseName { get; set; }

        [Display(Name = "Name of external moderator")]
        [Required(ErrorMessage = "Name of external moderator must be entered")]
        public string NameOfExternalModerator { get; set; }

        [Display(Name = "Date passed to external moderator")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]

        public DateTime DatePassedToExternalModerator { get; set; }

        [Display(Name = "Date of external moderator report")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]

        public DateTime DateOfExternalmoderatorReport { get; set; }

        [Display(Name = "Date of response to report")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]

        public DateTime DateOfResponseToReport { get; set; }

        [Display(Name = "Next due date for external moderation")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]

        public DateTime NextDueDateForExternalModeration { get; set; }

        [Display(Name = "Send email notification to")]
        [Required(ErrorMessage = "The email ID must be entered")]
        public string SendEmailNotificationTo { get; set; }

        public string FilePath { get; set; }
        public string FileName { get; set; }
        public bool? IsSentEmail { get; set; }

    }
}
