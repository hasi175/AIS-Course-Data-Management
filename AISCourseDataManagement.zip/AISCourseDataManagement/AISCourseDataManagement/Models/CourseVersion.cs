﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AISCourseDataManagement.Models
{
    public class CourseVersion
    {
        [Key]
        public int VersionID { get; set; }

        public int CourseId { get; set; }
        public Course Course { get; set; }

        [Display(Name = "Course Version")]
        [Required(ErrorMessage = "Course Version must be entered")]
        public string Version { get; set; }

        [Display(Name = "Course Description")]
        [Required(ErrorMessage = "Course Description must be entered")]
        public string VersionDescription { get; set; }

    }
}
