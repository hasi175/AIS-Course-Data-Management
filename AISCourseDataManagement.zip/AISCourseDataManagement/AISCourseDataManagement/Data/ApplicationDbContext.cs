﻿using AISCourseDataManagement.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace AISCourseDataManagement.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<Course> Course { get; set; }
        public DbSet<CourseVersion> CourseVersion { get; set; }
        public DbSet<ExternalModeration> externalModeration { get; set; }
        public DbSet<CourseDescriptor> courseDescriptor { get; set; }
        
    }
}
